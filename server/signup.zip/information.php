<?php

require 'authenticate-user.php';

$statement = $connection->prepare("SELECT email, firstname, surname, birthdate, telephone FROM account, person WHERE account.id = ? AND person.account = ?");
$statement->bind_param("ii", $identity, $identity);
$statement->execute();
$result = $statement->get_result();
$statement->close();

echo json_encode(($result->fetch_array(MYSQLI_ASSOC)));
